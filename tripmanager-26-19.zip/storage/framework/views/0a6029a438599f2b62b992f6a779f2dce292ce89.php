
    <div id="burger-menu">
        <span class="open-menu">
            <img src="<?php echo e(asset('assets/images/burger-menu.svg')); ?> " class="img-fluid" />
        </span>
        <span class="close-menu">
            <img src="<?php echo e(asset('assets/images/burger-menu-close.svg')); ?>" class="img-fluid" />
        </span>
    </div>
    <h3 class="heading-menu"> MAIN MENU </h3>

    <ul class="main-menu">
        <li class="menu-item <?php echo e((Request::path() == 'dashboard') ?  'active' : ''); ?>">
            <a href="<?php echo e(route('dashboard')); ?>">
                <img src="<?php echo e(asset('assets/images/dashboard.png')); ?>" class="img-fluid" alt="">
                <span>Dashboard</span>
            </a>
        </li>

        <li class="menu-item <?php echo e((Request::path() == 'all-activities') ?  'active' : ''); ?>">
            <a href="<?php echo e(route('all-activities')); ?>">
                <img src="<?php echo e(asset('assets/images/All-Activities.png')); ?>" class="img-fluid" alt="">
                <span>All Activities</span>
            </a>
        </li>

        <li class="menu-item <?php echo e((Request::path() == 'my-activities') ?  'active' : ''); ?>">
            <a href="<?php echo e(route('my-activities')); ?>">
                <img src="<?php echo e(asset('assets/images/locution-icon-2.png')); ?>" class="img-fluid" alt="">
                <span>My Activities</span>
            </a>
        </li>

        <li class="menu-item <?php echo e((Request::path() == 'documents') ?  'active' : ''); ?>">
            <a href="<?php echo e(route('documents')); ?>">
                <img src="<?php echo e(asset('assets/images/Documents.png')); ?>" class="img-fluid" alt="">
                <span>Documents</span>
            </a>
        </li>

        <li class="menu-item <?php echo e((Request::path() == 'crew-members') ?  'active' : ''); ?>">
            <a href="<?php echo e(route('crew-members')); ?>">
                <img src="<?php echo e(asset('assets/images/Crew.png')); ?>" class="img-fluid" alt="">
                <span>Crew Members</span>
            </a>
        </li>

        <li class="menu-item <?php echo e((Request::path() == 'activity-items') ?  'active' : ''); ?>">
            <a href="<?php echo e(route('activity-items')); ?>">
                <img src="<?php echo e(asset('assets/images/Activity-Items.png')); ?>" class="img-fluid" alt="">
                <span>Activity Items</span>
            </a>
        </li>

        <li class="menu-item <?php echo e((Request::path() == 'analytics') ?  'active' : ''); ?>">
            <a href="<?php echo e(route('analytics')); ?>">
                <img src="<?php echo e(asset('assets/images/Analysis.png')); ?>" class="img-fluid" alt="">
                <span>Analysis</span>
            </a>
        </li>

        <li class="menu-item <?php echo e((Request::path() == 'my-account') ?  'active' : ''); ?>">
            <a href="<?php echo e(route('my-account')); ?>">
                <img src="<?php echo e(asset('assets/images/My-Account.png')); ?>" class="img-fluid" alt="">
                <span>My Account</span>
            </a>
        </li>

        <li class="menu-item <?php echo e((Request::path() == 'settings') ?  'active' : ''); ?>">
            <a href="<?php echo e(route('settings')); ?>">
                <img src="<?php echo e(asset('assets/images/Setting.png')); ?>" class="img-fluid" alt="">
                <span>Settings</span>
            </a>
        </li>

        <li class="menu-item">

            <a href="<?php echo e(route('logout')); ?>"
                onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                <img src="<?php echo e(asset('assets/images/Logout.png')); ?>" class="img-fluid" alt=""> <span>Logout</span>
            </a>

            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                <?php echo csrf_field(); ?>
            </form>

        </li>
    </ul>



    <p class="last-text">

        CCT Activity Manager <br>

        Maintained by Voteq

    </p>
<?php /**PATH /var/www/html/laravel/tripmanager/resources/views/includes/sidebar.blade.php ENDPATH**/ ?>