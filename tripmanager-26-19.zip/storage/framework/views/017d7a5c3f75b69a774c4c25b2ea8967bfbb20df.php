<?php $__env->startSection('content'); ?>

    <div class="row dashboard_col" id="crew-members-edit">

        <div class="col-md-12 dashboard_Sec">

            <h1>Crew Members - Update an existing member</h1>
            <p class="sub-pages-text">Please amend any details below and click save changes to submit the updated
                information.</p>

        </div>

        <div class="col-md-12 activies_table">

            <div class="row activity_col">

                <div class="col-md-12 dashboard-heading-desc">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 upcoming_activities">
                            <h4>Member Information</h4>
                            <p class="col-12-descrapction">These details will be editable by the crew member once logged into
                                their account.</p>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-12">

                    <form class="teck-form" method="POST" action="<?php echo e(route('update-account')); ?>">

                        <?php echo csrf_field(); ?>

                        <div class="form-row">

                            <div class="form-group col-xl-8 col-lg-12">
                                <div class="form-row">
                                    <div class="form-group col-xl-4 col-lg-6">
                                        <label for="Name">NAME</label>
                                        <input type="text" class="form-control" id="Name" name="fullname"
                                            value="<?php echo e($crew_member->fullname); ?>">
                                        <input type="hidden" name="crewid" value="<?php echo e($crew_member->id); ?>">
                                    </div>

                                    <div class="form-group col-xl-4 col-lg-6">
                                        <label for="EmailAddress">EMAIL ADDRESS</label>
                                        <input type="email" class="form-control" id="EmailAddress" name="emailaddress"
                                            value="<?php echo e($crew_member->emailaddress); ?>">
                                    </div>


                                    <div class="form-group col-xl-4 col-lg-6">
                                        <label for="PrimaryNumber">PRIMARY NUMBER</label>
                                        <input type="text" class="form-control" id="PrimaryNumber" name="mobile"
                                            value="<?php echo e($crew_member->mobile); ?>">
                                    </div>


                                    <div class="form-group col-xl-4 col-lg-6">
                                        <label for="SecondaryNumber">SECONDARY NUMBER</label>
                                        <input type="text" class="form-control" name="secondarynumber"
                                            id="SecondaryNumber" value="<?php echo e($crew_member->secondarynumber); ?>">
                                    </div>

                                    <div class="form-group col-xl-4 col-lg-12">
                                        <label for="ActivityPreference">ACTIVITY PREFERENCE</label>
                                        <select id="ActivityPreference" name="boatpreference" class="form-control">
                                            <option>Please Select...</option>
                                            <option selected>Seth Ellis</option>
                                            <option>...</option>
                                            <option>...</option>
                                        </select>
                                    </div>


                                    <div class="col-lg-12 col-md-12 upcoming_activities">
                                        <h4>System Information</h4>
                                        <p class="col-12-descrapction">This information is not editable by the crew member
                                            and they will not be able to update it themselves.</p>
                                    </div>


                                    <div class="form-group col-xl-8 col-lg-12">
                                        <div class="form-row">

                                            <div class="form-group col-md-6">
                                                <label for="Initials">INITIALS</label>
                                                <input type="text" class="form-control" id="Initials" name="initials"
                                                    value="<?php echo e($crew_member->initials); ?>" disabled>
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label for="Username">USERNAME</label>
                                                <input type="text" class="form-control" id="Username" name="username"
                                                    value="<?php echo e($crew_member->username); ?>" disabled>
                                            </div>


                                            <div class="form-group col-md-6">
                                                <label for="AccountRole">ACCOUNT ROLE</label>
                                                <select id="AccountRole" name="user_type" class="form-control">
                                                    <option>Select Role</option>

                                                    <?php
                                                        $roles = \App\Models\Role::get();
                                                    ?>
                                                    <?php $__empty_1 = true; $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                        <option value="<?php echo e($role->id); ?>"
                                                            <?php echo e(isset($crew_member->user) && $crew_member->user->role['id'] == $role->id ? 'selected' : ''); ?>>
                                                            <?php echo e($role->role_name); ?></option>

                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                    <?php endif; ?>
                                                </select>
                                            </div>


                                            <div class="form-group col-md-6">
                                                <label for="CctMembershipNumber">CCT MEMBERSHIP NUMBER</label>
                                                <input type="number" class="form-control" id="CctMembershipNumber"
                                                    name="memnumber" value="<?php echo e($crew_member->memnumber); ?>">
                                            </div>


                                        </div>
                                    </div>
                                    <div class="form-group col-xl-4 col-lg-12">
                                        <div class="form-group col-md-12">
                                            <div><label>ADDITIONAL</label></div>
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" name="firstaid"
                                                    <?php echo e(!empty($crew_member->firstaid) ? 'checked' : ''); ?>

                                                    value="<?php echo e($crew_member->firstaid); ?>">
                                                <label class="form-check-label" for="First Aid">First Aid</label>
                                            </div>
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" name="cba"
                                                    <?php echo e(!empty($crew_member->cba) ? 'checked' : ''); ?>

                                                    value="<?php echo e($crew_member->cba); ?>">
                                                <label class="form-check-label" for="CBA">CBA</label>
                                            </div>

                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" name="rya"
                                                    <?php echo e(!empty($crew_member->rya) ? 'checked' : ''); ?>

                                                    value="<?php echo e($crew_member->rya); ?>">
                                                <label class="form-check-label" for="RYA">RYA</label>
                                            </div>


                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" name="iwa"
                                                    <?php echo e(!empty($crew_member->iwa) ? 'checked' : ''); ?>

                                                    value="<?php echo e($crew_member->iwa); ?>">
                                                <label class="form-check-label" for="IWA">IWA</label>
                                            </div>
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" name="skipper"
                                                    <?php echo e(!empty($crew_member->skipper) ? 'checked' : ''); ?>

                                                    value="<?php echo e($crew_member->skipper); ?>">
                                                <label class="form-check-label" for="Skipper">Skipper</label>
                                            </div>

                                            <div class="form-check">
                                                <input type="checkbox" class="form-check-input" name="optin"
                                                    id="optin" <?php echo e(!empty($crew_member->optin) ? 'checked' : ''); ?>

                                                    value="<?php echo e($crew_member->optin); ?>">
                                                <label for="optin">Opted in for Details</label>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group col-xl-8 col-lg-12">
                                        <div class="form-row">

                                            <div class="form-group col-md-6">
                                                <label for="privilege">Privilege</label>
                                                <input type="number" class="form-control" name="privilege"
                                                    id="privilege" value="<?php echo e($crew_member->privilege); ?>">
                                            </div>

                                            <div class="form-check">
                                                <label for="KeyHolder">Key Holder</label>
                                                <input class="form-control" type="text" id="KeyHolder"
                                                    name="keyholder" value="<?php echo e($crew_member->keyholder); ?>">
                                            </div>



                                            <div class="form-group col-md-6">
                                                <label for="privilege">First aid expiry</label>
                                                <input type="date" class="form-control" name="traveltime"
                                                    id="privilege" value="<?php echo e($crew_member->faexpire); ?>">
                                            </div>


                                        </div>
                                    </div>



                                    <div class="col-lg-12 col-md-12 upcoming_activities">
                                        <h4>Account Password</h4>
                                        <p class="col-12-descrapction">Please set a temporary password for the crew member.
                                            They can update this once logged in.</p>
                                    </div>



                                    <div class="form-group col-xl-8 col-lg-12">
                                        <div class="form-row">

                                            <div class="form-group col-md-6">
                                                <label for="TypeNewPassword">TYPE NEW PASSWORD</label>
                                                <input type="password" class="form-control" name="password"
                                                    id="TypeNewPassword" placeholder="*********">
                                            </div>

                                            <div class="form-group col-md-6">
                                                <label for="ReTypePassword">RE TYPE PASSWORD</label>
                                                <input type="password" class="form-control" name="confirmpassword"
                                                    id="ReTypePassword" placeholder="*********">
                                            </div>

                                        </div>
                                    </div>

                                </div>



                            </div>

                            <div class="form-group col-xl-4 col-lg-12">
                                <div class="profile-picture">
                                    <label>PROFILE PICTURE</label>
                                    <img src="<?php echo e(asset('assets/images/profile-picture.png')); ?>" />

                                    <div class="teck-btn bg-white upload-btn">
                                        <input type="file" name="profileImage" />
                                        <a href="#!"><img src="<?php echo e(asset('assets/images/camera.svg')); ?>"
                                                class="btn-icon-2" alt=""> Update Image </a>
                                    </div>
                                </div>
                            </div>


                        </div>



                        <div class="teck-btn">
                            <button type="submit" class="btn btn-primary"> <img
                                    src="<?php echo e(asset('assets/images/save.svg')); ?>" class="img-fluid"> Update User </button>
                        </div>
                    </form>


                </div>

            </div>

        </div>

    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel/tripmanager/resources/views/pages/crew-members-edit.blade.php ENDPATH**/ ?>