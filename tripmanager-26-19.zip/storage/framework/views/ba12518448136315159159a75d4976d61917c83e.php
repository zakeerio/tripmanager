<?php $__env->startSection('content'); ?>





  <section class="banner-section login-page">

      <div class="container-fluid">

          <div class="row">

              <div class="col-lg-6 col-md-12 m-auto " id="main-login">

                  <div class="row dashboard_col" id="login">

                      <div class="col-md-12 activies_table">

                          <div class="row activity_col">

                              <div class="col-md-12 dashboard-heading-desc upcoming_activities">
                                  <h4>Login Form</h4>
                                          <p class="col-12-descrapction">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
                                  <div class="row">
                                      <div class="col-lg-12 col-md-12 upcoming_activities">
                                        <?php if(Session::has('error')): ?>
                                        <div class="alert alert-danger">Error here</div>

                                        <?php endif; ?>

                                        <?php if(Session::has('success')): ?>
                                        <div class="alert alert-success">Login Successfully</div>

                                        <?php endif; ?>
                                      </div>
                                  </div>
                             </div>


                              <div class="col-md-12">

                                


                                  <form class="teck-form" method="POST" action="<?php echo e(route('login')); ?>">

                                    <?php echo csrf_field(); ?>

                                    <div class="form-row">
                                      <div class="form-group col-xl-6 col-lg-12">
                                        <label for="user-name"> USER NAME</label>
                                        <input id="user-name" type="text" class="form-control <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="username" value="<?php echo e(old('username')); ?>" required autocomplete="username" autofocus>

                                            <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                      </div>

                                      


                                      <div class="form-group col-xl-6 col-lg-12">
                                          <label for="usertype">Login As</label>
                                            <select name="user_type" class="form-control <?php $__errorArgs = ['user_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " id="usertype">
                                                <option value="">Select Role</option>

                                                <?php
                                                $roles = \App\Models\Role::get();
                                                ?>
                                                <?php $__empty_1 = true; $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <option value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                                <?php endif; ?>


                                            </select>
                                            

                                            <?php $__errorArgs = ['user_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                      </div>

                                      <div class="form-group col-xl-12 col-lg-12">
                                          <label for="ActivityTime">PASSWORD</label>
                                          <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password">

                                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                          <a href="<?php echo e(route('password.request')); ?>" class="ml-1 mt-2 d-inline-block">Forget Password</a>
                                      </div>

                                    </div>


                                      <div class="teck-btn">
                                          <button type="submit" class="btn btn-primary"> Login</button>
                                      </div>
                                  </form>


                              </div>

                          </div>

                      </div>

                  </div>

              </div>

          </div>

      </div>

    </section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.applogin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel/tripmanager/resources/views/auth/login.blade.php ENDPATH**/ ?>