<!doctype html>
<html>
<head>
   <?php echo $__env->make('includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>

<header id="header">

    <div class="container-fluid">

        <?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>


</header>


<section class="banner-section">

    <div class="container-fluid">

        <div class="row">
            <div class="col-lg-2 col-md-12" id="sidebar">

                <?php echo $__env->make('includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            </div>



            <div class="col-lg-10 col-md-12" id="main">
                

                 <?php echo $__env->yieldContent('content'); ?>

            </div>

        </div>

    </div>

</section>

<footer class="row">
       <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   </footer>

</body>
</html>
<?php /**PATH /var/www/html/laravel/tripmanager/resources/views/layouts/default.blade.php ENDPATH**/ ?>