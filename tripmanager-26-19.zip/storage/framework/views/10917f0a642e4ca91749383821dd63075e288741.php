<?php $__env->startSection('content'); ?>
    <div class="row dashboard_col" id="my-activities">
        <div class="col-md-12 dashboard_Sec">
            <div class="row">
                <div class="col-xl-8 col-lg-12 teck-acticites">
                    <h1>Role and Permissions</h1>
                    <p>This is a list of all the scheduled activities in the Activity Manager system..</p>
                </div>

                <div class="col-xl-4 col-lg-12">
                    <div class="teck-btn justify-content-end" id="teck-btn-pag-3">
                        <a href="<?php echo e(route('all-activities-create',2)); ?>"><img src="<?php echo e('assets/images/clander icon.png'); ?>" class="img-fluid">Create Permission</a>
                    </div>
                </div>
            </div>
        </div>


        <div class="col-md-12 activies_table">
            <div class="row activity_col">
                <div class="col-md-12">
                    <div class="teck-table">
                        <h2>Admin</h2>
                        <div class="modelname">
                            <h3>App\Posts</h3>
                            <div class="persmissions">
                                <div class="permissionitem">
                                    <h4>Permisison name</h4>
                                    <div class="permissionvalue d-flex ">
                                        <div class="form-group"><input type="checkbox" class="form-inpt-control" name="create"> Create </div>
                                        <div class="form-group"><input type="checkbox" class="form-inpt-control" name="edit"> Edit </div>
                                        <div class="form-group"><input type="checkbox" class="form-inpt-control" name="delete"> Delete </div>
                                    </div>
                                </div>
                                <div class="permissionitem">
                                    <h4>Permisison name</h4>
                                    <div class="permissionvalue d-flex ">
                                        <div class="form-group"><input type="checkbox" class="form-inpt-control" name="create"> Create </div>
                                        <div class="form-group"><input type="checkbox" class="form-inpt-control" name="edit"> Edit </div>
                                        <div class="form-group"><input type="checkbox" class="form-inpt-control" name="delete"> Delete </div>
                                    </div>
                                </div>
                                <div class="permissionitem">
                                    <h4>Permisison name</h4>
                                    <div class="permissionvalue d-flex ">
                                        <div class="form-group"><input type="checkbox" class="form-inpt-control" name="create"> Create </div>
                                        <div class="form-group"><input type="checkbox" class="form-inpt-control" name="edit"> Edit </div>
                                        <div class="form-group"><input type="checkbox" class="form-inpt-control" name="delete"> Delete </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                </div>
            </div>
        </div>

                <div class="col-md-12">
                    <div class="row btm-row">
                        <div class="col-md-6 teck-showin-text">Showing <b>1-50</b> of <b>46</b> available activities.</div>
                        <div class="col-md-6">
                            <div class="pagination-row">
                                <button class="btn-prev teck-arrow">
                                    < </button>
                                        <ul class="pagination">
                                            <li class="active"> 1 </li>
                                            <li> 2 </li>
                                            <li> 3 </li>
                                            <li> 4 </li>
                                        </ul>
                                        <button class="btn-next teck-arrow">></button>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel/tripmanager/resources/views/pages/roles-permissions.blade.php ENDPATH**/ ?>