<?php $__env->startSection('content'); ?>


    <div class="row dashboard_col" id="crew-members">
        <div class="col-md-12 dashboard_Sec">
            <div class="row">
                <div class="col-xl-7 col-lg-12">
                    <h1>Crew Members</h1>
                    <p class="sub-pages-text">This is a list of all the scheduled activities in the
                        Activity Manager system..</p>
                </div>

                <div class="col-xl-5 col-lg-12">
                    <div class="btn-filter">
                        <div class="teck-btn justify-content-start bg-white">
                            <a href="#!"><img src="<?php echo e(asset('assets/images/rol icon.png')); ?>" class="btn-icon-2"
                                    alt=""> Filter by Role </a>

                            <ul class="teck-dropdown">
                                <li>Item 01</li>
                                <li>Item 02</li>
                                <li>Item 03</li>
                            </ul>
                        </div>



                        <div class="teck-btn justify-content-end">
                            <a href="<?php echo e(route('crew-members-create')); ?>"><img
                                    src="<?php echo e(asset('assets/images/user.png')); ?>" class="img-fluid">Create new user</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="col-md-12 activies_table">
            <div class="row activity_col">
                <div class="col-lg-8 col-md-12 upcoming_activities">

                </div>

                <div class="col-md-12">
                    <div class="teck-table">

                        <table class="rwd-table" id="datatables">
                            <thead>
                                <tr>
                                    <th class="th-heading">Name</th>
                                    <th class="th-heading">Email</th>
                                    <th class="th-heading-brief">Phone</th>
                                    <th class="th-heading">First Aid</th>
                                    <th class="th-heading">Key Holder</th>
                                    <th class="th-heading">Skipper</th>
                                    <th class="th-heading">RYA</th>
                                    <th class="th-heading">CBA</th>
                                    <th class="th-heading">Role</th>
                                    <th class="th-heading">Action</th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php $__empty_1 = true; $__currentLoopData = $crew_members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crewmember): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    

                                    


                                    <tr>
                                        <td>
                                            <div class="table-div">
                                                <img src="<?php echo e(asset('assets/images/Chacha.png')); ?>" class="img-fluid"
                                                    alt="">
                                                <p> <b> <?php echo e($crewmember->fullname); ?></b> <br> (<?php echo e($crewmember->initials); ?>)
                                                </p>
                                            </div>
                                        </td>
                                        <td> <?php echo e($crewmember->emailaddress); ?> </td>
                                        <td> <?php echo e($crewmember->mobile); ?> </td>
                                        <td> <?php echo e($crewmember->firstaid); ?> </td>
                                        <td> <?php echo e($crewmember->keyholder); ?></td>
                                        <td> <?php echo e($crewmember->skipper); ?> </td>
                                        <td> <?php echo e($crewmember->rya); ?> </td>
                                        <td> <?php echo e($crewmember->cba); ?> </td>
                                        <td> <?php echo e($crewmember->user ? Str::ucfirst($crewmember->user->role['name']) : '(No Role)'); ?>

                                        </td>

                                        <td class="action">
                                            <div class="dropdown">
                                                <button class="btn" type="button" id="BtnAction" data-toggle="dropdown"
                                                    aria-haspopup="true" aria-expanded="false">
                                                    <span></span>
                                                    <span></span>
                                                    <span></span>
                                                </button>
                                                <div class="dropdown-menu" aria-labelledby="BtnAction">
                                                    <a class="dropdown-item"
                                                        href="<?php echo e(route('crew-members-edit', $crewmember->id)); ?>/">Edit</a>
                                                    <a class="dropdown-item" href="#">Delete</a>
                                                </div>
                                            </div>
                                        </td>

                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php endif; ?>
                                

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>


            

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel/tripmanager/resources/views/pages/crew-members.blade.php ENDPATH**/ ?>